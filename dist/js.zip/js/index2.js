$(document).ready(function () {
    //initialize swiper when document ready
     var swiper = new Swiper('.swiper-container', {
      pagination: {
        el: '.swiper-pagination',
        dynamicBullets: true,
      },
    });
});